Leaflet Maps Marker plugin uses map icons from the Maps Icons Collection by Nicolas Mollet (http://mapicons.nicolasmollet.com/).
By default, a preselection of about 100 icons (from more than 700 available icons) has been added to the plugin.
On first activation of the plugin, the zip-file mapicons.zip gets unzipped into the directory \wp-content\uploads\leaflet-maps-marker-icons
of your WordPress installation (note: you might have to enter your ftp-credentials once depending on your configuration)
If you want to add more map icons, please download the desired icons from http://mapicons.nicolasmollet.com/ 
and upload them to the directory \wp-content\uploads\leaflet-maps-marker-icons

PLEASE DO NOT DELETE THIS FILE FROM YOUR MARKER ICONS DIRECTORY AS IT IS USED TO CHECK IF INSTALLATION WAS SUCCESSFUL!